var searchData=
[
  ['mval',['mval',['../struct_u_a_r_t___b_a_u_d_r_a_t_e___v_a_l_u_e___d_i_v___m_u_l.html#a5befc5e0503cd766fe62752a6885dc7e',1,'UART_BAUDRATE_VALUE_DIV_MUL']]]
];
