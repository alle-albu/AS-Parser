var searchData=
[
  ['ok',['OK',['../group___d_r_v___g_e_n_e_r_a_l.html#gga32c27cc471df37f4fc818d65de0a56c4a2bc49ec37d6a5715dd23e85f1ff5bb59',1,'drv_general.h']]],
  ['out_5fof_5fsync',['OUT_OF_SYNC',['../group___d_r_v___g_e_n_e_r_a_l.html#gga32c27cc471df37f4fc818d65de0a56c4a0349eb8a2b71d8beb7bbdc50e055a3ff',1,'drv_general.h']]]
];
