var searchData=
[
  ['software_5ftimer_5fmode',['SOFTWARE_TIMER_MODE',['../group___timer_software.html#ga413309eac385f405a83eff562a903f8a',1,'timer_software.h']]],
  ['status',['STATUS',['../group___d_r_v___g_e_n_e_r_a_l.html#ga32c27cc471df37f4fc818d65de0a56c4',1,'drv_general.h']]]
];
