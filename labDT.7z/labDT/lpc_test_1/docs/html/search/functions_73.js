var searchData=
[
  ['systemcoreclockupdate',['SystemCoreClockUpdate',['../system___l_p_c177x__8x_8c.html#ae0c36a9591fe6e9c45ecb21a794f0f0f',1,'SystemCoreClockUpdate(void):&#160;system_LPC177x_8x.c'],['../system___l_p_c177x__8x_8h.html#ae0c36a9591fe6e9c45ecb21a794f0f0f',1,'SystemCoreClockUpdate(void):&#160;system_LPC177x_8x.c']]],
  ['systeminit',['SystemInit',['../system___l_p_c177x__8x_8c.html#a93f514700ccf00d08dbdcff7f1224eb2',1,'SystemInit(void):&#160;system_LPC177x_8x.c'],['../system___l_p_c177x__8x_8h.html#a93f514700ccf00d08dbdcff7f1224eb2',1,'SystemInit(void):&#160;system_LPC177x_8x.c']]]
];
