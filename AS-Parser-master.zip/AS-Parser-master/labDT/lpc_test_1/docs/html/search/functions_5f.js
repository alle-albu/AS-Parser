var searchData=
[
  ['_5fsys_5fexit',['_sys_exit',['../_retarget_8c.html#a7b9ac395975163ef0a591db5c48ad7ae',1,'Retarget.c']]],
  ['_5fttywrch',['_ttywrch',['../_retarget_8c.html#a73909e782fdfcefe282862189d139dd5',1,'Retarget.c']]]
];
