var searchData=
[
  ['timeout',['TIMEOUT',['../group___d_r_v___g_e_n_e_r_a_l.html#gga32c27cc471df37f4fc818d65de0a56c4aad9dee005a3d0f9137b2ac1e0869f89b',1,'drv_general.h']]],
  ['true',['TRUE',['../group___d_r_v___g_e_n_e_r_a_l.html#ggaec7e62084419d7857ae740a4c68241cfaa82764c3079aea4e60c80e45befbb839',1,'drv_general.h']]]
];
