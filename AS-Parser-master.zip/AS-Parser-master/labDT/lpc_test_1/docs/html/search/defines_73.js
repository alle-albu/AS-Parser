var searchData=
[
  ['scs_5fval',['SCS_Val',['../system___l_p_c177x__8x_8c.html#aa643f228c03274d2aad339bf03d55e04',1,'system_LPC177x_8x.c']]],
  ['sdram_5fbase_5faddr',['SDRAM_BASE_ADDR',['../drv__sdram_8h.html#ad050b7d75f459f2c91aff366ffa6d5db',1,'drv_sdram.h']]],
  ['sdram_5frefresh',['SDRAM_REFRESH',['../drv__sdram_8h.html#a25beb3e7ae1fcf2b943ff2d22d6a325a',1,'drv_sdram.h']]],
  ['sdram_5fsize',['SDRAM_SIZE',['../drv__sdram_8h.html#a82db1eeff764aa7e568483199a0832b8',1,'drv_sdram.h']]],
  ['sdram_5ftapr',['SDRAM_TAPR',['../drv__sdram_8h.html#a0047cf3ec7f73fb468493bffbe5457cd',1,'drv_sdram.h']]],
  ['sdram_5ftdal',['SDRAM_TDAL',['../drv__sdram_8h.html#a9845df07f28412df3b507229d4206377',1,'drv_sdram.h']]],
  ['sdram_5ftmrd',['SDRAM_TMRD',['../drv__sdram_8h.html#a5c8c0d1f0afb668049fdadf420f7aee3',1,'drv_sdram.h']]],
  ['sdram_5ftras',['SDRAM_TRAS',['../drv__sdram_8h.html#a6970701fa2f373c8add41a374ff45493',1,'drv_sdram.h']]],
  ['sdram_5ftrc',['SDRAM_TRC',['../drv__sdram_8h.html#a79f005214551a79c0bde41ccd51a54c7',1,'drv_sdram.h']]],
  ['sdram_5ftrfc',['SDRAM_TRFC',['../drv__sdram_8h.html#ab2a22e57108a05109491956286291e5d',1,'drv_sdram.h']]],
  ['sdram_5ftrp',['SDRAM_TRP',['../drv__sdram_8h.html#a151d0603d3b97dd3c099732a8c890adb',1,'drv_sdram.h']]],
  ['sdram_5ftrrd',['SDRAM_TRRD',['../drv__sdram_8h.html#a6bd70442257a8722134a711c9de9fa8c',1,'drv_sdram.h']]],
  ['sdram_5ftwr',['SDRAM_TWR',['../drv__sdram_8h.html#ae9a0212f01930fe74d77aa67f986eb22',1,'drv_sdram.h']]],
  ['sdram_5ftxsr',['SDRAM_TXSR',['../drv__sdram_8h.html#a5fd22f4aed855f302e992e9148d840c7',1,'drv_sdram.h']]],
  ['sw_5ftimer_5fperiod',['SW_TIMER_PERIOD',['../timer__software_8h.html#ab2583f375c860ec599ace5c857fadff8',1,'timer_software.h']]]
];
