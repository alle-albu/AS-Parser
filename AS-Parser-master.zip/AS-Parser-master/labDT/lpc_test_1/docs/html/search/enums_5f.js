var searchData=
[
  ['_5ftouchscrstate_5ft',['_TouchScrState_t',['../group___d_r_v___t_o_u_c_h_s_c_r_e_e_n.html#ga60a38e3d0e321d01fa0f8bbca710e860',1,'drv_touchscreen.c']]]
];
