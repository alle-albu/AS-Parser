var searchData=
[
  ['sdram_5fbase_5faddr',['SDRAM_BASE_ADDR',['../group___d_r_v___s_d_r_a_m.html#gad050b7d75f459f2c91aff366ffa6d5db',1,'drv_sdram.h']]],
  ['sdram_5fsize',['SDRAM_SIZE',['../group___d_r_v___s_d_r_a_m.html#ga82db1eeff764aa7e568483199a0832b8',1,'drv_sdram.h']]],
  ['software_5ftimer',['SOFTWARE_TIMER',['../struct_s_o_f_t_w_a_r_e___t_i_m_e_r.html',1,'']]],
  ['software_5ftimer_5fmode',['SOFTWARE_TIMER_MODE',['../group___timer_software.html#ga413309eac385f405a83eff562a903f8a',1,'timer_software.h']]],
  ['status',['STATUS',['../group___d_r_v___g_e_n_e_r_a_l.html#ga32c27cc471df37f4fc818d65de0a56c4',1,'drv_general.h']]],
  ['system_5flpc177x_5f8x_2ec',['system_LPC177x_8x.c',['../system___l_p_c177x__8x_8c.html',1,'']]],
  ['system_5flpc177x_5f8x_2eh',['system_LPC177x_8x.h',['../system___l_p_c177x__8x_8h.html',1,'']]],
  ['systemcoreclock',['SystemCoreClock',['../system___l_p_c177x__8x_8c.html#aa3cd3e43291e81e795d642b79b6088e6',1,'SystemCoreClock():&#160;system_LPC177x_8x.c'],['../system___l_p_c177x__8x_8h.html#aa3cd3e43291e81e795d642b79b6088e6',1,'SystemCoreClock():&#160;system_LPC177x_8x.c']]],
  ['systemcoreclockupdate',['SystemCoreClockUpdate',['../system___l_p_c177x__8x_8c.html#ae0c36a9591fe6e9c45ecb21a794f0f0f',1,'SystemCoreClockUpdate(void):&#160;system_LPC177x_8x.c'],['../system___l_p_c177x__8x_8h.html#ae0c36a9591fe6e9c45ecb21a794f0f0f',1,'SystemCoreClockUpdate(void):&#160;system_LPC177x_8x.c']]],
  ['systeminit',['SystemInit',['../system___l_p_c177x__8x_8c.html#a93f514700ccf00d08dbdcff7f1224eb2',1,'SystemInit(void):&#160;system_LPC177x_8x.c'],['../system___l_p_c177x__8x_8h.html#a93f514700ccf00d08dbdcff7f1224eb2',1,'SystemInit(void):&#160;system_LPC177x_8x.c']]]
];
