var searchData=
[
  ['wiznet_5fhw_5faddress',['WIZNET_HW_ADDRESS',['../struct_w_i_z_n_e_t___h_w___a_d_d_r_e_s_s.html',1,'']]],
  ['wiznet_5fip_5faddress',['WIZNET_IP_ADDRESS',['../struct_w_i_z_n_e_t___i_p___a_d_d_r_e_s_s.html',1,'']]],
  ['wiznet_5fphy_5fstatus',['WIZNET_PHY_STATUS',['../struct_w_i_z_n_e_t___p_h_y___s_t_a_t_u_s.html',1,'']]],
  ['wiznet_5fsocket_5fcallbacks',['WIZNET_SOCKET_CALLBACKS',['../struct_w_i_z_n_e_t___s_o_c_k_e_t___c_a_l_l_b_a_c_k_s.html',1,'']]],
  ['wiznet_5fsocket_5fmemory_5fmap',['WIZNET_SOCKET_MEMORY_MAP',['../struct_w_i_z_n_e_t___s_o_c_k_e_t___m_e_m_o_r_y___m_a_p.html',1,'']]]
];
