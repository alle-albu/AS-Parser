var searchData=
[
  ['read_5fwrite_5ftimeout_5fms',['read_write_timeout_ms',['../struct_u_a_r_t___m_a_p.html#a02fb5aeefae9c210916c6532b43b5d83',1,'UART_MAP']]],
  ['red',['red',['../struct_l_c_d___p_i_x_e_l.html#a7aa9fb42709ab6aafad503edfddff307',1,'LCD_PIXEL']]]
];
