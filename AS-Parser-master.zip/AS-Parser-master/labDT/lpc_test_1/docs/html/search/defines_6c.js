var searchData=
[
  ['lcd_5fheight',['LCD_HEIGHT',['../drv__lcd_8h.html#a53a8b2a971de4b88047192655a48b651',1,'drv_lcd.h']]],
  ['lcd_5fwidth',['LCD_WIDTH',['../drv__lcd_8h.html#a19693eac3018d3e7800fde141921b812',1,'drv_lcd.h']]]
];
