var searchData=
[
  ['blue',['blue',['../struct_l_c_d___p_i_x_e_l.html#ab33d68bcedfdcaac788d00cfe3b75736',1,'LCD_PIXEL']]]
];
