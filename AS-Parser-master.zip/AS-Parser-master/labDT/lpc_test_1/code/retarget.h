#ifndef __RETARGET_H
#define __RETARGET_H

#define DEBUG_UART UART_0

void initRetargetDebugSystem(void);

#endif

