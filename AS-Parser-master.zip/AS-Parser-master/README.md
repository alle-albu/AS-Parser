# AS-Parser

DT project

compile by typing the following command in the command prompt:
gcc a.c main.c -g

then run typing:
a
